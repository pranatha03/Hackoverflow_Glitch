// ASTRO SENTINEL — Express Server

const express = require("express");
const cors    = require("cors");
const aiRoutes = require("./routes/aiRoutes");

const app  = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

// Routes
app.use("/api", aiRoutes);

app.listen(PORT, () => {
  console.log(`Express server running on http://localhost:${PORT}`);
});
