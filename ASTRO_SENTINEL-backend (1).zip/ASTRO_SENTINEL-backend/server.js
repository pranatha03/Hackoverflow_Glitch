// ASTRO SENTINEL – Express Server

const express = require("express");
const cors = require("cors");
const aiRoutes = require("./routes/aiRoutes");

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json({ limit: "50mb" }));

// Routes
app.use("/api", aiRoutes);

// Global error handler
app.use((err, req, res, next) => {
    res.status(err.status || 500).json({ error: err.message || "Internal server error" });
});

app.listen(PORT, () => {
    console.log(`Express server running on http://localhost:${PORT}`);
});
